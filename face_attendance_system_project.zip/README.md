
# Face Recognition Attendance System (Starter)

This is a beginner Python project that uses OpenCV to access the camera and simulate an attendance system.

## Features
- Access webcam using OpenCV
- Display live camera feed
- Press 'A' to mark attendance
- Press 'Q' to quit

## Installation

```bash
pip install -r requirements.txt
python attendance.py
```

## Technologies
- Python
- OpenCV
