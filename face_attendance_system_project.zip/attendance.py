
import cv2
import datetime

cam = cv2.VideoCapture(0)

print("Face Attendance Camera Started")
print("Press 'q' to quit")

while True:
    ret, frame = cam.read()

    if not ret:
        break

    # show camera frame
    cv2.imshow("Attendance Camera", frame)

    # example attendance log
    key = cv2.waitKey(1)

    if key & 0xFF == ord('a'):
        now = datetime.datetime.now()
        print("Attendance Marked at:", now)

    if key & 0xFF == ord('q'):
        break

cam.release()
cv2.destroyAllWindows()
